class MainController < ApplicationController
  def home
  end

  def skin_type
  end

  def ingredients
  end

  def products
  end

  def about
  end
  
  def natural
  end
  
end
