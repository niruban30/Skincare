// This is a manifest file that'll be compiled into application.js, which will include all the files
// listed below.
//
// Any JavaScript/Coffee file within this directory, lib/assets/javascripts, vendor/assets/javascripts,
// or any plugin's vendor/assets/javascripts directory can be referenced here using a relative path.
//
// It's not advisable to add code directly here, but if you do, it'll appear at the bottom of the
// compiled file. JavaScript code in this file should be added after the last require_* statement.
//
// Read Sprockets README (https://github.com/rails/sprockets#sprockets-directives) for details
// about supported directives.
//
//= require jquery
//= require jquery_ujs
//= require turbolinks
//= require_tree .

function generate_key(){
    var number=Math.random();
    var key= number.toString(36).substr(2,9);
    return key;
    }

function add_item_to_list(key,namedItem) {
    $("<tr><td>"
    +namedItem.name
    +"</td><td id=d" + key + ">"
    +namedItem.item
    +"</td><td>"
    +"<button id=" + key + ">Delete Item</button>"
    +"</td></tr>").appendTo("#itemList");
    $('button#'+key).click(function(event){
        localStorage.removeItem(key);
        $('td#d'+key).addClass("strikeThrough")
        
    });
}


// Most of the content moved from here to app/views/main/home.html.erb
// to ensure it always loads when that page is selected.
// However, I have left the prompt to enter a name here as we do want that
// to load when the site is loaded and only then.

$(function() {
    var userName=prompt("Please enter your name");
    sessionStorage.setItem('userName', userName);
});

//var handler = Gmaps.build('Google');
///handler.buildingMap({ internal: {id: 'geolocation'} },
//unction(){
     //if(navigator.geolocation)

//navigator.geolocation.getCurrentPosition(displayOnMap);
 //});
 
//function displayOnMap(position){
    //var marker= handler.addMarker({
    //lat:position.coords.51.242336)
    //lng:position.coords.-0.570229)
     //});
     //handler.map.centerOn(marker);
 //};     


 
 
 
 

 
 
 
 

 
 
 