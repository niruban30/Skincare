function validation() {
    var x = document.forms["chicken"]["name"].value;
    if (x == "") {
        alert("Come on RIYA Fill it out");
        return false;
    }
}