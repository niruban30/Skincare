Rails.application.routes.draw do

  match '/skin_type' => 'main#skin_type', via: :get

  match '/ingredients' => 'main#ingredients', via: :get

  match '/products' => 'main#products', via: :get

  match '/about' => 'main#about', via: :get
    
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  root 'main#home'
end
